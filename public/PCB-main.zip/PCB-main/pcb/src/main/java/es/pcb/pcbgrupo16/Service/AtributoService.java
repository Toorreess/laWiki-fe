package es.pcb.pcbgrupo16.Service;

public class AtributoService {
}
